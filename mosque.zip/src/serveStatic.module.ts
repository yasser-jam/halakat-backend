import { Module } from '@nestjs/common';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { UploadController } from './file/file.controller'; // Adjust path as needed

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', 'uploads'), // Path to the uploads folder
      serveRoot: '/uploads', // URL path prefix to access the files
    }),
  ],
  controllers: [UploadController],
})
export class AppModule {}
